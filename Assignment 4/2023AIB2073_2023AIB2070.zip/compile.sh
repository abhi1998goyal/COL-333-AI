g++ startup_code.cpp -o startup_code
