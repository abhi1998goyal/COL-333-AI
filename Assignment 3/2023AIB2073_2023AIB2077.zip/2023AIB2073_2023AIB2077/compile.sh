#!/bin/bash
python3 nothingtocompile.py