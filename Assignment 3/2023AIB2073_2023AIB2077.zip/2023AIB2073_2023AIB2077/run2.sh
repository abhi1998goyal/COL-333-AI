#!/bin/bash
python3 compute.py 2 $1