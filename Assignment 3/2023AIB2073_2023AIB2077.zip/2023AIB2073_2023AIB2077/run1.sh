#!/bin/bash
chmod 777 minisat
python3 compute.py 1 $1 