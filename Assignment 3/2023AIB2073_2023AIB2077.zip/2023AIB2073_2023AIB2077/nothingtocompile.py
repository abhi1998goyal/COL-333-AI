
if __name__=='__main__':
    print("nothing to compile for python")