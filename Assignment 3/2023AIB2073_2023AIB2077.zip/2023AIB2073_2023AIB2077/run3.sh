#!/bin/bash
python3 compute_best.py $1